
/*
-validate URL with HTTP with regex idk (create a method for it)
-Make the url passed in from the argument (URL)
-Make sure to alphabetize it
-Create a method for numHops, to track - set default vlue




import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.io.IOException;
import java.util.HashSet;
import java.util.Collections;



public class Main {

    public static void main(String[] args) {


        //HashSet <String> set = new HashSet<>();


        try {
            //Creating a HTTPUrlConnection instance by using the openConnection method of URL class
            URL my_url = new URL("http://courses.washington.edu/css502/dimpsey");
            HttpURLConnection con = (HttpURLConnection) my_url.openConnection();

            con.setRequestMethod("GET"); //Set the method for the URL request


            //Reading the response code
            // 1xx : Informational
            // 2xx : Success
            // 3xx : Redirection
            // 4xx : Client Error
            // 5xx server error

            boolean redirect = false;
            int status = con.getResponseCode();
            if(status != HttpURLConnection.HTTP_OK)  //deals with error 200
            {
                if(status == HttpURLConnection.HTTP_BAD_REQUEST
                    || status == HttpURLConnection.HTTP_UNAUTHORIZED || status == HttpURLConnection.HTTP_PAYMENT_REQUIRED
                    || status == HttpURLConnection.HTTP_FORBIDDEN ||status == HttpURLConnection.HTTP_NOT_FOUND
                    || status == HttpURLConnection.HTTP_BAD_METHOD || status == HttpURLConnection.HTTP_NOT_ACCEPTABLE
                    || status == HttpURLConnection.HTTP_SERVER_ERROR || status == HttpURLConnection.HTTP_BAD_GATEWAY)
                {
                    redirect = false;
                }

                else if(status == HttpURLConnection.HTTP_MOVED_TEMP
                    || status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_SEE_OTHER) {
                    redirect = true;
                }

            }
            System.out.println("Response Code" + status);
            if(redirect)
            {
                String newUrl = con.getHeaderField("Location");
                con = (HttpURLConnection) new URL(newUrl).openConnection();
                System.out.println("Redirect to URL" + newUrl); //deals with error 303,302,301
            }


            BufferedReader in = new BufferedReader(new InputStreamReader(my_url.openStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();

            while ((inputLine = in.readLine()) != null)
            {
                content.append(inputLine);

            }

            //System.out.println(content.toString());
            System.out.println("***** AFTER ******");

            String patternString = "<a\\s+href\\s*=(?<url>\"[^\"]*\"|[^\\s>]*)\\s*>"; //regex to remove <a href
            Pattern pattern2 = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern2.matcher(content.toString()); //input is entered here

            while (matcher.find())
            {
                String destination = matcher.group("url").replaceAll("['\"]", "");
                System.out.println(destination);

            }
            in.close();
        }

         catch (IOException e) {
            e.printStackTrace();
        }

        catch (PatternSyntaxException e)
        {
            e.printStackTrace();
        }


    }

}

 */





public class Main {

    public static void main(String[] args) {



        try
        {
            Crawl myClient = new Crawl();
            myClient.validateURL("http://courses.washington.edu/css502/dimpsey");
            System.out.println("Valid URLS that have successfully connected :");
            //System.out.println(myClient.success);
            //System.out.println("\n--------------\n\n");
            //System.out.println("Broken URLS that did not successfully connect :");
            //System.out.println(myClient.failed);
        }

        catch (Exception e)
        {
            System.out.print(e.getMessage());
        }
    }
}



















