
/*
//crawl method - Give a URL to make a HTTP request for a web page
//returns a list of links
//validate all URL's
//Use regex to find <a href
//Use HashSet to delete duplicate links
//deal with HTTP response requests
//
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.IOException;
import java.lang.String;
import java.lang.StringBuffer;


public class Crawl {

    //public int MAX_LINKS_TO_SEARCH = 10;

    //public List<String> linksCollected = new ArrayList<String>(); //LIST

    //List<String> pagestoVisit = new ArrayList<String>();
    //Set<String> pagesVisited = new HashSet<String>(); //every single time you


    public void validateURL(String URL) throws Exception //*Take care of redirects now. Wait no, numHops first.
    {
        try {
            //Creating the HTTPConnection
            URL my_url = new URL(URL);
            HttpURLConnection curr = (HttpURLConnection) my_url.openConnection(); //curr = current connection
            curr.setRequestMethod("GET"); //Set the method for the URL request
            int URLStatus = curr.getResponseCode();

            if (URLStatus >= 400) //if it's broken
            {
                System.out.println(URL + " is broken");

            } else {
                System.out.println(URL);
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(my_url.openStream()));
            String inputLine;
            StringBuffer content = new StringBuffer();
            while ((inputLine = in.readLine()) != null) //reading in all the lines
            {
                content.append(inputLine);
                content.append(System.lineSeparator());
            }
            System.out.println(content);
            String test = content.toString();
            test.split("a href=");
            //System.out.println(test);
            String patternToSearchFor = ".*http:.*";
            Pattern p = Pattern.compile(patternToSearchFor, Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(test);

            while (m.find()) {
                //linksCollected GETS ALL of your LINKS.
                //Now we need to start think how to check against pagesVisited
                for (int i = 0; i <= m.groupCount(); i++) {
                    m.group(i).strip(); //took me ages
                    System.out.println(m.group(i).replaceAll("['\"]", "").replaceAll("<a href=", "").replaceAll("<.*?>", "")
                            .replaceAll("\\s+", "").replaceAll(">.*?", "").replaceAll("\\(.*\\)", ""));

                }
                in.close();
            }



        } catch (IOException ioe) {
            System.out.print("ERROR");
        }
    }
}

